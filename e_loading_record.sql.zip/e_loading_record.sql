-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 01, 2018 at 03:17 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `e_loading_record`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Added_By` varchar(50) NOT NULL,
  `First_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `hashed_password` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `City` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `Added_By`, `First_Name`, `Last_Name`, `Username`, `hashed_password`, `Email`, `Address`, `City`) VALUES
(30, 'admin', 'Dianne', 'Regacion', 'admin', '$2P3/lU8fzLJk', 'dregacion@gmail.com', 'davao', 'Davao City'),
(33, 'admin', 'Dayan', 'Regacion', 'dayan', '$2P3/lU8fzLJk', 'dregacion@gmail.com', 'Davao', 'Davao City');

--
-- Triggers `admin`
--
DROP TRIGGER IF EXISTS `admin_after_insert`;
DELIMITER //
CREATE TRIGGER `admin_after_insert` AFTER INSERT ON `admin`
 FOR EACH ROW BEGIN
INSERT INTO users_activity
(Username, Activity, Changedon)
VALUES
(NEW.Added_By, 'Inserts new admin', NOW());
END
//
DELIMITER ;
DROP TRIGGER IF EXISTS `after_admin_update`;
DELIMITER //
CREATE TRIGGER `after_admin_update` AFTER UPDATE ON `admin`
 FOR EACH ROW BEGIN
insert into users_activity
(Username, Activity, Changedon)
VALUES
(NEW.Username, 'Updates personal profile', NOW());
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `load_records`
--

CREATE TABLE IF NOT EXISTS `load_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Date` date NOT NULL,
  `Time` time NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Mobile_Number` varchar(15) NOT NULL,
  `Amount_of_Load` int(11) NOT NULL,
  `Amount_Paid` int(11) NOT NULL,
  `Network` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=101 ;

--
-- Dumping data for table `load_records`
--

INSERT INTO `load_records` (`id`, `Date`, `Time`, `Username`, `Mobile_Number`, `Amount_of_Load`, `Amount_Paid`, `Network`) VALUES
(96, '2018-01-01', '10:38:35', 'dianne', '09123456789', 30, 33, 'Globe'),
(97, '2018-01-01', '10:47:48', 'dianne', '09123456789', 20, 23, 'TM'),
(98, '2018-01-01', '10:48:24', 'dianne', '09876543211', 30, 33, 'Smart'),
(100, '2018-01-01', '10:51:27', 'aljun', '09123456789', 20, 23, 'Smart');

-- --------------------------------------------------------

--
-- Table structure for table `networks`
--

CREATE TABLE IF NOT EXISTS `networks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Added_By` varchar(50) NOT NULL,
  `Network` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `networks`
--

INSERT INTO `networks` (`id`, `Added_By`, `Network`) VALUES
(9, 'admin', 'Smart'),
(10, 'admin', 'Globe'),
(11, 'admin', 'TM');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Added_By` varchar(50) NOT NULL,
  `First_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `hashed_password` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `City` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `Added_By`, `First_Name`, `Last_Name`, `Username`, `hashed_password`, `Email`, `Address`, `City`) VALUES
(25, 'admin', 'Dianne', 'Regacion', 'dianne', '$2P3/lU8fzLJk', 'dregacion@gmail.com', 'Davao', 'Davao City'),
(26, 'admin', 'Aljun', 'Lofranco', 'aljun', '$2P3/lU8fzLJk', 'aljun.051694@gmail.com', 'compostela', 'Compostela');

--
-- Triggers `users`
--
DROP TRIGGER IF EXISTS `users_after_insert`;
DELIMITER //
CREATE TRIGGER `users_after_insert` AFTER INSERT ON `users`
 FOR EACH ROW BEGIN
INSERT INTO users_activity
(Username, Activity, Changedon)
VALUES
(NEW.Added_By, 'Inserts new user', NOW());
END
//
DELIMITER ;
DROP TRIGGER IF EXISTS `after_users_update`;
DELIMITER //
CREATE TRIGGER `after_users_update` AFTER UPDATE ON `users`
 FOR EACH ROW BEGIN
INSERT INTO users_activity
(Username, Activity, Changedon)
VALUES
(NEW.Username, 'Updates personal profile', NOW());
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `users_activity`
--

CREATE TABLE IF NOT EXISTS `users_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) NOT NULL,
  `Activity` varchar(100) NOT NULL,
  `Changedon` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `users_activity`
--

INSERT INTO `users_activity` (`id`, `Username`, `Activity`, `Changedon`) VALUES
(58, 'admin', 'Inserts new user', '2018-01-01 10:37:21'),
(59, 'admin', 'Updates personal profile', '2018-01-01 10:41:44'),
(60, 'admin', 'Inserts new user', '2018-01-01 10:42:16'),
(61, 'admin', 'Inserts new admin', '2018-01-01 10:44:01'),
(62, 'aljun', 'Updates personal profile', '2018-01-01 10:50:51');

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_load_records`
--
CREATE TABLE IF NOT EXISTS `view_load_records` (
`Username` varchar(50)
,`Date` date
,`Time` time
,`Mobile_Number` varchar(15)
,`Amount_of_Load` int(11)
,`Amount_Paid` int(11)
,`Network` varchar(50)
,`id` int(11)
);
-- --------------------------------------------------------

--
-- Structure for view `view_load_records`
--
DROP TABLE IF EXISTS `view_load_records`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_load_records` AS select `user`.`Username` AS `Username`,`smart`.`Date` AS `Date`,`smart`.`Time` AS `Time`,`smart`.`Mobile_Number` AS `Mobile_Number`,`smart`.`Amount_of_Load` AS `Amount_of_Load`,`smart`.`Amount_Paid` AS `Amount_Paid`,`smart`.`Network` AS `Network`,`smart`.`id` AS `id` from (`users` `user` left join `load_records` `smart` on((`user`.`Username` = `smart`.`Username`)));
