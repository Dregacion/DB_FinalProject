-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 30, 2017 at 03:08 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `e_loading_record`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Added_By` varchar(50) NOT NULL,
  `First_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `hashed_password` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `City` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `Added_By`, `First_Name`, `Last_Name`, `Username`, `hashed_password`, `Email`, `Address`, `City`) VALUES
(30, 'admin', 'Dianne', 'Regacion', 'admin', '$2P3/lU8fzLJk', 'dregacion@gmail.com', 'Davao', 'Davao City');

--
-- Triggers `admin`
--
DROP TRIGGER IF EXISTS `admin_after_insert`;
DELIMITER //
CREATE TRIGGER `admin_after_insert` AFTER INSERT ON `admin`
 FOR EACH ROW BEGIN
INSERT INTO users_activity
(Username, Activity, Changedon)
VALUES
(NEW.Added_By, 'Inserts new admin', NOW());
END
//
DELIMITER ;
DROP TRIGGER IF EXISTS `after_admin_update`;
DELIMITER //
CREATE TRIGGER `after_admin_update` AFTER UPDATE ON `admin`
 FOR EACH ROW BEGIN
insert into users_activity
(Username, Activity, Changedon)
VALUES
(NEW.Username, 'Updates personal profile', NOW());
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `load_records`
--

CREATE TABLE IF NOT EXISTS `load_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Date` date NOT NULL,
  `Time` time NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Mobile_Number` bigint(15) NOT NULL,
  `Amount_of_Load` int(11) NOT NULL,
  `Amount_Paid` int(11) NOT NULL,
  `Network` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=80 ;

--
-- Dumping data for table `load_records`
--

INSERT INTO `load_records` (`id`, `Date`, `Time`, `Username`, `Mobile_Number`, `Amount_of_Load`, `Amount_Paid`, `Network`) VALUES
(76, '2017-12-26', '20:02:17', 'dianne', 9123456789, 20, 23, 'Globe'),
(79, '2017-12-30', '01:51:00', 'dianne', 9123456789, 10, 13, 'Globe');

-- --------------------------------------------------------

--
-- Table structure for table `networks`
--

CREATE TABLE IF NOT EXISTS `networks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Added_By` varchar(50) NOT NULL,
  `Network` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `networks`
--

INSERT INTO `networks` (`id`, `Added_By`, `Network`) VALUES
(4, 'admin', 'Smart'),
(5, 'admin', 'Globe'),
(7, 'admin', 'TM');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Added_By` varchar(50) NOT NULL,
  `First_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `hashed_password` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `City` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `Added_By`, `First_Name`, `Last_Name`, `Username`, `hashed_password`, `Email`, `Address`, `City`) VALUES
(17, 'admin', 'Dianne', 'Regacion', 'dianne', '$2P3/lU8fzLJk', 'dregacion@gmail.com', 'Davao', 'Davao City');

--
-- Triggers `users`
--
DROP TRIGGER IF EXISTS `users_after_insert`;
DELIMITER //
CREATE TRIGGER `users_after_insert` AFTER INSERT ON `users`
 FOR EACH ROW BEGIN
INSERT INTO users_activity
(Username, Activity, Changedon)
VALUES
(NEW.Added_By, 'Inserts new user', NOW());
END
//
DELIMITER ;
DROP TRIGGER IF EXISTS `after_users_update`;
DELIMITER //
CREATE TRIGGER `after_users_update` AFTER UPDATE ON `users`
 FOR EACH ROW BEGIN
INSERT INTO users_activity
(Username, Activity, Changedon)
VALUES
(NEW.Username, 'Updates personal profile', NOW());
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `users_activity`
--

CREATE TABLE IF NOT EXISTS `users_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) NOT NULL,
  `Activity` varchar(100) NOT NULL,
  `Changedon` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

--
-- Dumping data for table `users_activity`
--


-- --------------------------------------------------------

--
-- Stand-in structure for view `view_load_records`
--
CREATE TABLE IF NOT EXISTS `view_load_records` (
`Username` varchar(50)
,`Date` date
,`Time` time
,`Mobile_Number` bigint(15)
,`Amount_of_Load` int(11)
,`Amount_Paid` int(11)
,`Network` varchar(50)
,`id` int(11)
);
-- --------------------------------------------------------

--
-- Structure for view `view_load_records`
--
DROP TABLE IF EXISTS `view_load_records`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_load_records` AS select `user`.`Username` AS `Username`,`smart`.`Date` AS `Date`,`smart`.`Time` AS `Time`,`smart`.`Mobile_Number` AS `Mobile_Number`,`smart`.`Amount_of_Load` AS `Amount_of_Load`,`smart`.`Amount_Paid` AS `Amount_Paid`,`smart`.`Network` AS `Network`,`smart`.`id` AS `id` from (`users` `user` left join `load_records` `smart` on((`user`.`Username` = `smart`.`Username`)));
